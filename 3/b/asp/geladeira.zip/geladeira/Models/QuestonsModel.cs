namespace geladeira.Models;

public class QuestonsModel
{
  public string? q1 { get; set; }
  public string? q2 { get; set; }
  public string? q3 { get; set; }
  public string? q4 { get; set; }
  public string? q5 { get; set; }
  public string? q6 { get; set; }
  public string? q7 { get; set; }
  public string? q8 { get; set; }
  public string? q9 { get; set; }
  public string? q10 { get; set; }
}
