namespace janela.Models;

public class UsersModel
{
    public string? name { get; set; }
    public string? age { get; set; }
    public string? profession { get; set; }
}
